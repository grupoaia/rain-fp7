# mocRS
Official R package of the remote sensing course of the MSc Environmental Geography at Marburg University.
