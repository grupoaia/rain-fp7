library(testthat)
library(satellite)

test_check("satellite")
